const apiUrl = "http://localhost:3000/albums";
let albums = [];
let selectedAlbumId = null;

const albumList = document.getElementById("albumList");
const infoPanel = document.getElementById("infoPanel");
const addBtn = document.getElementById("addAlbumBtn");
const addForm = document.getElementById("addForm");
const albumDetails = document.getElementById("albumDetails");

const albumFormHTML = `
  <label for="albumName">Album Name:</label>
  <input type="text" id="albumName" />
  <label for="bandName">Band Name:</label>
  <input type="text" id="bandName" />
  <label for="songCount">Number of Songs:</label>
  <input type="number" id="songCount" min="1" />
  <label for="duration">Duration (min):</label>
  <input type="number" id="duration" min="1" />
  <p id="formMsg" class="error-msg"></p>
`;

async function fetchAlbums() {
  try {
    const res = await fetch(apiUrl);
    const data = await res.json();
    if (!res.ok) throw new Error(data.description);
    return data;
  } catch (err) {
    console.error(err.message);
  }
}

async function sendAlbum(data, method, id = "") {
  try {
    const res = await fetch(`${apiUrl}/${id}`, {
      method,
      headers: { "Content-Type": "application/json; charset=UTF-8" },
      body: method === "DELETE" ? null : JSON.stringify(data),
    });
    const responseData = await res.json();
    if (!res.ok) throw new Error(responseData.description);
    return responseData;
  } catch (err) {
    console.error(err.message);
  }
}

window.onload = async () => {
  albums = await fetchAlbums();
  infoPanel.style.display = "none";
  addForm.style.display = "none";
  if (albums.length > 0) renderAlbumList();
  else albumList.style.display = "none";
};

function renderAlbumList() {
  albumList.innerHTML = albums.map(album => `<li data-id="${album.id}">${album.name}</li>`).join("");
  albumList.style.display = "block";
  addBtn.style.display = "block";
  addAlbumListeners();
}

function addAlbumListeners() {
  albumList.querySelectorAll("li").forEach(li => {
    li.addEventListener("click", () => {
      selectedAlbumId = li.dataset.id;
      displayAlbumDetails();
    });
  });
}

function displayAlbumDetails() {
  const album = albums.find(a => a.id == selectedAlbumId);
  if (!album) return;

  albumList.style.display = "none";
  addBtn.style.display = "none";
  infoPanel.style.display = "block";

  albumDetails.innerHTML = `
    <button onclick="closePanel()">Back</button>
    <p class="data-item"><strong>Album Name:</strong> ${album.name}</p>
    <p class="data-item"><strong>Band:</strong> ${album.band}</p>
    <p class="data-item"><strong>Songs:</strong> ${album.numberOfSongs}</p>
    <p class="data-item"><strong>Duration:</strong> ${album.length} min</p>
    <div class="button-group">
      <button onclick="renderEditForm()">Edit Album</button>
      <button onclick="removeAlbum()">Delete Album</button>
    </div>
    <div id="editFormContainer"></div>
  `;
}

function renderEditForm() {
  const album = albums.find(a => a.id == selectedAlbumId);
  if (!album) return;

  const formHTML = `
    <div id="editForm">
      <label for="albumName">Album Name:</label>
      <input type="text" id="albumName" value="${album.name}" />
      <label for="bandName">Band Name:</label>
      <input type="text" id="bandName" value="${album.band}" />
      <label for="songCount">Number of Songs:</label>
      <input type="number" id="songCount" value="${album.numberOfSongs}" min="1" />
      <label for="duration">Duration (min):</label>
      <input type="number" id="duration" value="${album.length}" min="1" />
      <p id="formMsg" class="error-msg"></p>
      <button onclick="updateAlbum()">Save Changes</button>
    </div>
  `;

  document.getElementById("editFormContainer").innerHTML = formHTML;
}


function displayAddForm() {
  addBtn.style.display = "none";
  albumList.style.display = "none";
  addForm.innerHTML = `<button onclick="closePanel()">Back</button>${albumFormHTML}<button onclick="createAlbum()">Add Album</button>`;
  addForm.style.display = "block";
}

async function createAlbum() {
  const name = document.getElementById("albumName").value.trim();
  const band = document.getElementById("bandName").value.trim();
  const numberOfSongs = parseInt(document.getElementById("songCount").value);
  const length = parseInt(document.getElementById("duration").value);

  if (!name || !band || numberOfSongs < 1 || length < 1) {
    return showError("formMsg", "Please fill out all fields correctly.");
  }

  if (albums.some(a => a.name === name)) {
    return showError("formMsg", "An album with this name already exists.");
  }

  await sendAlbum({ name, band, numberOfSongs, length }, "POST");
  albums = await fetchAlbums();
  closePanel();
  renderAlbumList();
}

async function updateAlbum() {
  const name = document.getElementById("albumName").value.trim();
  const band = document.getElementById("bandName").value.trim();
  const numberOfSongs = parseInt(document.getElementById("songCount").value);
  const length = parseInt(document.getElementById("duration").value);

  if (!name || !band || numberOfSongs < 1 || length < 1) {
    return showError("formMsg", "Please fill out all fields correctly.");
  }

  await sendAlbum({ name, band, numberOfSongs, length }, "PUT", selectedAlbumId);
  albums = await fetchAlbums();
  closePanel();
  renderAlbumList();
}

async function removeAlbum() {
  await sendAlbum(null, "DELETE", selectedAlbumId);
  albums = await fetchAlbums();
  closePanel();
  if (albums.length > 0) renderAlbumList();
  else albumList.style.display = "none";
}

function closePanel() {
  addForm.style.display = "none";
  infoPanel.style.display = "none";
  albumDetails.innerHTML = "";
  addForm.innerHTML = "";
  if (albums.length > 0) renderAlbumList();
  else albumList.style.display = "none";
}

function showError(id, message) {
  document.getElementById(id).textContent = message;
}

function showEditForm() {
  const album = albums.find(a => a.id == selectedAlbumId);
  if (!album) return;

  const editForm = `
      <div id="updateField">
          <label for="albumNameInput" class="inputLabel">Album Name:</label>
          <input type="text" id="albumNameInput" value="${album.name}"><br>

          <label for="bandNameInput" class="inputLabel">Band Name:</label>
          <input type="text" id="BandNameInput" value="${album.band}"><br>

          <label for="numberOfSongsInput" class="inputLabel">Number of Songs:</label>
          <input type="number" id="numberOfSongsInput" min="1" value="${album.numberOfSongs}"><br>

          <label for="lengthInput" class="inputLabel">Length (min):</label>
          <input type="number" id="lengthInput" min="1" value="${album.length}"><br>

          <p id="message"></p>
          <button id="albumUpdateButton" onclick="updateAlbum()">Save Changes</button>
      </div>
  `;
  datas.innerHTML += editForm;
}

async function writeInformation() {
  albumList.style.display = "none";
  addButton.style.display = "none";
  information.style.display = "block";
  datas.innerHTML = "";

  const album = albums.find(a => a.id == selectedAlbumId);
  if (!album) return;

  datas.innerHTML = `
      <button id="back" onclick="closeInformation()">Back</button>
      <div class="data">
          <h2>${album.name}</h2>
          <p><strong>Band:</strong> ${album.band}</p>
          <p><strong>Number of Songs:</strong> ${album.numberOfSongs}</p>
          <p><strong>Length:</strong> ${album.length} min</p>
      </div>
      <div class="button-group">
          <button id="editAlbumBtn" onclick="showEditForm()">Edit Album</button>
          <button id="deleteAlbumBtn" onclick="deleteAlbum()">Delete Album</button>
      </div>
  `;
}