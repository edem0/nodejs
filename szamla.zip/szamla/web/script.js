// Handle sidebar navigation
document.querySelectorAll(".sidebar nav button").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
      document.getElementById(btn.dataset.page).classList.add("active");
  
      // Load invoices when navigating to edit-invoice or new-invoice page
      if (btn.dataset.page === "edit-invoice") {
        fetchAndRenderInvoices();
      } else if (btn.dataset.page === "new-invoice") {
        populateCustomerIssuerSelects();
      }
    });
  });
  
  // API Base URL
  const API = "http://localhost:2010";
  
  // Generic fetch and render list
  async function fetchAndRender(url, listId, createItem) {
    const res = await fetch(url);
    const data = await res.json();
    const list = document.getElementById(listId);
    list.innerHTML = "";
    data.forEach(item => list.appendChild(createItem(item)));
  }
  
  // Create customer list item
  function createCustomerItem(customer) {
    const li = document.createElement("li");
    li.textContent = customer.name;
    const actions = document.createElement("div");
    actions.className = "actions";
  
    const editBtn = document.createElement("button");
    editBtn.className = "edit";
    editBtn.textContent = "Edit";
    editBtn.onclick = () => {
      const form = document.querySelector("#customer-form");
      form.name.value = customer.name;
      form.dataset.id = customer.id;
    };
  
    const deleteBtn = document.createElement("button");
    deleteBtn.className = "delete";
    deleteBtn.textContent = "Delete";
    deleteBtn.onclick = async () => {
      await fetch(`${API}/customers/${customer.id}`, { method: "DELETE" });
      fetchAndRender(`${API}/customers`, "customer-list", createCustomerItem);
    };
  
    actions.append(editBtn, deleteBtn);
    li.appendChild(actions);
    return li;
  }
  
  // Create issuer list item
  function createIssuerItem(issuer) {
    const li = document.createElement("li");
    li.textContent = issuer.name;
    const actions = document.createElement("div");
    actions.className = "actions";
  
    const editBtn = document.createElement("button");
    editBtn.className = "edit";
    editBtn.textContent = "Edit";
    editBtn.onclick = () => {
      const form = document.querySelector("#issuer-form");
      form.name.value = issuer.name;
      form.dataset.id = issuer.id;
    };
  
    const deleteBtn = document.createElement("button");
    deleteBtn.className = "delete";
    deleteBtn.textContent = "Delete";
    deleteBtn.onclick = async () => {
      await fetch(`${API}/issuers/${issuer.id}`, { method: "DELETE" });
      fetchAndRender(`${API}/issuers`, "issuer-list", createIssuerItem);
    };
  
    actions.append(editBtn, deleteBtn);
    li.appendChild(actions);
    return li;
  }
  
  // Customer Form submit
  const customerForm = document.getElementById("customer-form");
  customerForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = customerForm.name.value.trim();
    if (!name) return;
  
    const id = customerForm.dataset.id;
    const method = id ? "PUT" : "POST";
    const url = id ? `${API}/customers/${id}` : `${API}/customers`;
  
    await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name })
    });
  
    customerForm.reset();
    delete customerForm.dataset.id;
    fetchAndRender(`${API}/customers`, "customer-list", createCustomerItem);
  });
  
  // Issuer Form submit
  const issuerForm = document.getElementById("issuer-form");
  issuerForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = issuerForm.name.value.trim();
    if (!name) return;
  
    const id = issuerForm.dataset.id;
    const method = id ? "PUT" : "POST";
    const url = id ? `${API}/issuers/${id}` : `${API}/issuers`;
  
    await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name })
    });
  
    issuerForm.reset();
    delete issuerForm.dataset.id;
    fetchAndRender(`${API}/issuers`, "issuer-list", createIssuerItem);
  });
  
  // Populate customer and issuer select dropdowns for new invoice form
  async function populateCustomerIssuerSelects() {
    const customersRes = await fetch(`${API}/customers`);
    const customers = await customersRes.json();
    const issuersRes = await fetch(`${API}/issuers`);
    const issuers = await issuersRes.json();
  
    const customerSelect = document.getElementById("customer-select");
    const issuerSelect = document.getElementById("issuer-select");
  
    customerSelect.innerHTML = '<option value="" disabled selected>Select Customer</option>';
    issuerSelect.innerHTML = '<option value="" disabled selected>Select Issuer</option>';
  
    customers.forEach(c => {
      const opt = document.createElement("option");
      opt.value = c.id;
      opt.textContent = c.name;
      customerSelect.appendChild(opt);
    });
  
    issuers.forEach(i => {
      const opt = document.createElement("option");
      opt.value = i.id;
      opt.textContent = i.name;
      issuerSelect.appendChild(opt);
    });
  }
  
  // Invoice Form submit (Basic example, extend as needed)
  const invoiceForm = document.getElementById("invoice-form");
  invoiceForm.addEventListener("submit", async (e) => {
    e.preventDefault();
  
    const data = {
      invoiceNumber: invoiceForm.invoiceNumber.value,
      created: invoiceForm.created.value,
      fulfilled: invoiceForm.fulfilled.value,
      deadline: invoiceForm.deadline.value,
      total: parseFloat(invoiceForm.total.value),
      vat: parseFloat(invoiceForm.vat.value),
      customerId: invoiceForm.customerId.value,
      issuerId: invoiceForm.issuerId.value,
    };
  
    await fetch(`${API}/invoices`, {
      method: "POST",
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
  
    invoiceForm.reset();
    alert("Invoice saved!");
  });
  
  // Create invoice list item (for edit/delete)
  function createInvoiceItem(invoice) {
    const li = document.createElement("li");
    li.textContent = `#${invoice.invoiceNumber} - Total: ${invoice.total.toFixed(2)} | Customer: ${invoice.customerName} | Issuer: ${invoice.issuerName}`;
  
    const actions = document.createElement("div");
    actions.className = "actions";
  
    const editBtn = document.createElement("button");
    editBtn.className = "edit";
    editBtn.textContent = "Edit";
    editBtn.onclick = () => {
      alert("Edit invoice feature not implemented yet.");
      // You could add code here to populate the invoice form for editing
    };
  
    const deleteBtn = document.createElement("button");
    deleteBtn.className = "delete";
    deleteBtn.textContent = "Delete";
    deleteBtn.onclick = async () => {
      await fetch(`${API}/invoices/${invoice.id}`, { method: "DELETE" });
      fetchAndRenderInvoices();
    };
  
    actions.append(editBtn, deleteBtn);
    li.appendChild(actions);
    return li;
  }
  
  // Fetch and render invoices in the edit-invoice section
  async function fetchAndRenderInvoices() {
    const res = await fetch(`${API}/invoices`);
    const invoices = await res.json();
    const list = document.getElementById("invoice-list");
    list.innerHTML = "";
    invoices.forEach(inv => list.appendChild(createInvoiceItem(inv)));
  }
  
  // Initialize lists on load
  fetchAndRender(`${API}/customers`, "customer-list", createCustomerItem);
  fetchAndRender(`${API}/issuers`, "issuer-list", createIssuerItem);
  